while true
do
    sleep 12m
    wget -q -O/dev/null $BASE_URL_OF_BOT
done